import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-UMIDYVP4.js";
import "./chunk-QJVLQKZV.js";
import "./chunk-JX5HDXVX.js";
import "./chunk-HXFVV2UZ.js";
import "./chunk-IIXO7YIU.js";
import "./chunk-54NBLQQP.js";
import "./chunk-3MWYMNVP.js";
import "./chunk-ZVWDWOQO.js";
import "./chunk-LJYIMYAW.js";
import "./chunk-C27DBZK2.js";
import "./chunk-2UVUUPPC.js";
import "./chunk-K54IFBYX.js";
import "./chunk-6DU2HRTW.js";
export {
  MatDivider,
  MatDividerModule
};
