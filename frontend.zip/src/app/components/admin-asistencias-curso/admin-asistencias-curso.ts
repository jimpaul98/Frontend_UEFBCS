import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-asistencias-curso',
  imports: [],
  templateUrl: './admin-asistencias-curso.html',
  styleUrl: './admin-asistencias-curso.scss'
})
export class AdminAsistenciasCurso {

}
