import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-notas-curso',
  imports: [],
  templateUrl: './admin-notas-curso.html',
  styleUrl: './admin-notas-curso.scss'
})
export class AdminNotasCurso {

}
